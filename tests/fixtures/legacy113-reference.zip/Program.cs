using CipherCapsule.Core;
byte[] pw=Limits.Utf8.GetBytes("  日本語🔑 Capsule! 2026  ");
try{if(args.Length==0){using var template=File.OpenRead("Viewer113.exe");Container.Generate(template,"legacy113.exe","Legacy v1.1.3 fixture 日本語",BodyKind.TEXT,[],pw,false,default);Console.WriteLine("Generated using unchanged v1.1.3 Core and template");}else{using var c=Container.Unlock(args[0],pw,default);Console.WriteLine(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(Limits.Utf8.GetBytes(c.Manifest.Body))));}}finally{Sodium.Wipe(pw);}
